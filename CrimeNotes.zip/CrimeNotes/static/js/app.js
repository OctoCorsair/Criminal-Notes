document.addEventListener("DOMContentLoaded", () => {
  const menu = document.getElementById("menuToggle");
  const sidebar = document.getElementById("sidebar");
  if (menu && sidebar) menu.addEventListener("click", () => sidebar.classList.toggle("sidebar-open"));

  document.querySelectorAll("[data-confirm]").forEach(form => {
    form.addEventListener("submit", event => {
      if (!window.confirm(form.dataset.confirm || "Tem certeza?")) event.preventDefault();
    });
  });

  document.querySelectorAll(".flash-close").forEach(button => {
    button.addEventListener("click", () => button.closest(".flash")?.remove());
  });

  document.querySelectorAll(".tabs a").forEach(link => {
    link.addEventListener("click", () => {
      document.querySelectorAll(".tabs a").forEach(item => item.classList.remove("selected"));
      link.classList.add("selected");
    });
  });

  // Preserve the section anchor after form submissions and highlight its tab.
  const hash = window.location.hash;
  if (hash) {
    const link = document.querySelector(`.tabs a[href="${hash}"]`);
    if (link) link.classList.add("selected");
  }
});
