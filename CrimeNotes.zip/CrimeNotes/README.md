# 🕵️ CrimeNotes

**Every clue tells a story.** Um caderno digital para organizar investigações fictícias, pistas, suspeitos e cronologias de romances policiais.

Aplicação web desenvolvida com **Python, Flask, SQLite, HTML, CSS e JavaScript**.

## Funcionalidades

- Cadastro, edição e exclusão de casos.
- Registro de suspeitos, motivações, álibis e observações.
- Cadastro de pistas com categoria e nível de confiabilidade.
- Cronologia de acontecimentos com data e descrição.
- Cadastro de locais e anotações por caso.
- Busca textual por casos, suspeitos e pistas.
- Banco SQLite criado automaticamente na primeira execução.
- Interface responsiva em português.

## Requisitos

- Python 3.10 ou superior
- pip

## Instalação

```bash
git clone https://github.com/OctoCorsair/CrimeNotes.git
cd CrimeNotes

python -m venv .venv
```

Ative o ambiente virtual:

**Windows (PowerShell):**
```powershell
.venv\Scripts\Activate.ps1
```

**Linux/macOS:**
```bash
source .venv/bin/activate
```

Instale as dependências e inicie:

```bash
pip install -r requirements.txt
python app.py
```

Abra `http://127.0.0.1:5000` no navegador.

## Estrutura

```text
CrimeNotes/
├── app.py
├── database.py
├── requirements.txt
├── database/
├── static/
│   ├── css/style.css
│   └── js/app.js
└── templates/
```

## Observação de segurança

Este projeto é um protótipo local para uso pessoal. Antes de publicar na internet, altere `SECRET_KEY`, desative o modo debug, implemente autenticação, proteção CSRF e revise as configurações de implantação. Não armazene dados pessoais sensíveis.

## Autor

**Isaque Maciel — OctoCorsair**  
[GitHub](https://github.com/OctoCorsair) · [LinkedIn](https://www.linkedin.com/in/isaque-m-877595337)

---
*Desenvolvido como projeto da OctoCorsair Labs.*
