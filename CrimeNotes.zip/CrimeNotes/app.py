from flask import Flask, render_template, request, redirect, url_for, flash, abort
from database import init_db, get_db
from datetime import datetime

app = Flask(__name__)
app.config["SECRET_KEY"] = "change-this-secret-key-before-deploying"
init_db()

def get_case_or_404(case_id):
    case = get_db().execute("SELECT * FROM cases WHERE id = ?", (case_id,)).fetchone()
    if case is None:
        abort(404)
    return case

@app.route("/")
def index():
    db = get_db()
    cases = db.execute("""
        SELECT c.*,
          (SELECT COUNT(*) FROM suspects s WHERE s.case_id=c.id) AS suspect_count,
          (SELECT COUNT(*) FROM clues cl WHERE cl.case_id=c.id) AS clue_count
        FROM cases c ORDER BY c.updated_at DESC, c.id DESC
    """).fetchall()
    stats = {
        "cases": db.execute("SELECT COUNT(*) FROM cases").fetchone()[0],
        "suspects": db.execute("SELECT COUNT(*) FROM suspects").fetchone()[0],
        "clues": db.execute("SELECT COUNT(*) FROM clues").fetchone()[0],
        "open": db.execute("SELECT COUNT(*) FROM cases WHERE status != 'Concluído'").fetchone()[0],
    }
    return render_template("index.html", cases=cases, stats=stats)

@app.route("/cases/new", methods=["GET", "POST"])
def new_case():
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        if not title:
            flash("O título do caso é obrigatório.", "error")
            return render_template("case_form.html", case=None)
        now = datetime.now().isoformat(timespec="seconds")
        db = get_db()
        cur = db.execute("""INSERT INTO cases (title, summary, status, genre, created_at, updated_at)
                            VALUES (?, ?, ?, ?, ?, ?)""",
                         (title, request.form.get("summary", "").strip(),
                          request.form.get("status", "Em andamento"),
                          request.form.get("genre", "").strip(), now, now))
        db.commit()
        flash("Caso criado com sucesso.", "success")
        return redirect(url_for("case_detail", case_id=cur.lastrowid))
    return render_template("case_form.html", case=None)

@app.route("/cases/<int:case_id>")
def case_detail(case_id):
    case = get_case_or_404(case_id)
    db = get_db()
    suspects = db.execute("SELECT * FROM suspects WHERE case_id=? ORDER BY created_at DESC", (case_id,)).fetchall()
    clues = db.execute("SELECT * FROM clues WHERE case_id=? ORDER BY created_at DESC", (case_id,)).fetchall()
    events = db.execute("SELECT * FROM timeline WHERE case_id=? ORDER BY event_date ASC, id ASC", (case_id,)).fetchall()
    locations = db.execute("SELECT * FROM locations WHERE case_id=? ORDER BY name", (case_id,)).fetchall()
    notes = db.execute("SELECT * FROM notes WHERE case_id=? ORDER BY updated_at DESC", (case_id,)).fetchall()
    return render_template("case_detail.html", case=case, suspects=suspects, clues=clues,
                           events=events, locations=locations, notes=notes)

@app.route("/cases/<int:case_id>/edit", methods=["GET", "POST"])
def edit_case(case_id):
    case = get_case_or_404(case_id)
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        if not title:
            flash("O título do caso é obrigatório.", "error")
        else:
            db = get_db()
            db.execute("""UPDATE cases SET title=?, summary=?, status=?, genre=?, updated_at=? WHERE id=?""",
                       (title, request.form.get("summary", "").strip(),
                        request.form.get("status", "Em andamento"),
                        request.form.get("genre", "").strip(),
                        datetime.now().isoformat(timespec="seconds"), case_id))
            db.commit()
            flash("Caso atualizado.", "success")
            return redirect(url_for("case_detail", case_id=case_id))
    return render_template("case_form.html", case=case)

@app.post("/cases/<int:case_id>/delete")
def delete_case(case_id):
    get_case_or_404(case_id)
    db = get_db()
    db.execute("DELETE FROM cases WHERE id=?", (case_id,))
    db.commit()
    flash("Caso e seus registros foram excluídos.", "success")
    return redirect(url_for("index"))

@app.post("/cases/<int:case_id>/suspects")
def add_suspect(case_id):
    get_case_or_404(case_id)
    name = request.form.get("name", "").strip()
    if not name:
        flash("Informe o nome do suspeito.", "error")
    else:
        db = get_db()
        db.execute("""INSERT INTO suspects (case_id, name, role, motive, alibi, notes, created_at)
                      VALUES (?, ?, ?, ?, ?, ?, ?)""",
                   (case_id, name, request.form.get("role", "").strip(),
                    request.form.get("motive", "").strip(), request.form.get("alibi", "").strip(),
                    request.form.get("notes", "").strip(), datetime.now().isoformat(timespec="seconds")))
        db.execute("UPDATE cases SET updated_at=? WHERE id=?", (datetime.now().isoformat(timespec="seconds"), case_id))
        db.commit()
        flash("Suspeito adicionado.", "success")
    return redirect(url_for("case_detail", case_id=case_id) + "#suspects")

@app.post("/suspects/<int:item_id>/delete")
def delete_suspect(item_id):
    row = get_db().execute("SELECT case_id FROM suspects WHERE id=?", (item_id,)).fetchone()
    if row is None: abort(404)
    case_id = row["case_id"]
    db = get_db()
    db.execute("DELETE FROM suspects WHERE id=?", (item_id,))
    db.commit()
    flash("Suspeito removido.", "success")
    return redirect(url_for("case_detail", case_id=case_id) + "#suspects")

@app.post("/cases/<int:case_id>/clues")
def add_clue(case_id):
    get_case_or_404(case_id)
    title = request.form.get("title", "").strip()
    if not title:
        flash("Informe o título da pista.", "error")
    else:
        db = get_db()
        db.execute("""INSERT INTO clues (case_id, title, description, category, reliability, created_at)
                      VALUES (?, ?, ?, ?, ?, ?)""",
                   (case_id, title, request.form.get("description", "").strip(),
                    request.form.get("category", "Outra"),
                    request.form.get("reliability", "Não avaliada"),
                    datetime.now().isoformat(timespec="seconds")))
        db.execute("UPDATE cases SET updated_at=? WHERE id=?", (datetime.now().isoformat(timespec="seconds"), case_id))
        db.commit()
        flash("Pista registrada.", "success")
    return redirect(url_for("case_detail", case_id=case_id) + "#clues")

@app.post("/clues/<int:item_id>/delete")
def delete_clue(item_id):
    row = get_db().execute("SELECT case_id FROM clues WHERE id=?", (item_id,)).fetchone()
    if row is None: abort(404)
    case_id = row["case_id"]
    db = get_db()
    db.execute("DELETE FROM clues WHERE id=?", (item_id,))
    db.commit()
    flash("Pista removida.", "success")
    return redirect(url_for("case_detail", case_id=case_id) + "#clues")

@app.post("/cases/<int:case_id>/timeline")
def add_event(case_id):
    get_case_or_404(case_id)
    title = request.form.get("title", "").strip()
    date = request.form.get("event_date", "").strip()
    if not title or not date:
        flash("Informe o acontecimento e a data.", "error")
    else:
        db = get_db()
        db.execute("INSERT INTO timeline (case_id, title, event_date, description) VALUES (?, ?, ?, ?)",
                   (case_id, title, date, request.form.get("description", "").strip()))
        db.execute("UPDATE cases SET updated_at=? WHERE id=?", (datetime.now().isoformat(timespec="seconds"), case_id))
        db.commit()
        flash("Acontecimento adicionado à cronologia.", "success")
    return redirect(url_for("case_detail", case_id=case_id) + "#timeline")

@app.post("/timeline/<int:item_id>/delete")
def delete_event(item_id):
    row = get_db().execute("SELECT case_id FROM timeline WHERE id=?", (item_id,)).fetchone()
    if row is None: abort(404)
    case_id = row["case_id"]
    db = get_db()
    db.execute("DELETE FROM timeline WHERE id=?", (item_id,))
    db.commit()
    flash("Acontecimento removido.", "success")
    return redirect(url_for("case_detail", case_id=case_id) + "#timeline")

@app.post("/cases/<int:case_id>/locations")
def add_location(case_id):
    get_case_or_404(case_id)
    name = request.form.get("name", "").strip()
    if not name:
        flash("Informe o nome do local.", "error")
    else:
        db = get_db()
        db.execute("INSERT INTO locations (case_id, name, address, description) VALUES (?, ?, ?, ?)",
                   (case_id, name, request.form.get("address", "").strip(), request.form.get("description", "").strip()))
        db.execute("UPDATE cases SET updated_at=? WHERE id=?", (datetime.now().isoformat(timespec="seconds"), case_id))
        db.commit()
        flash("Local registrado.", "success")
    return redirect(url_for("case_detail", case_id=case_id) + "#locations")

@app.post("/locations/<int:item_id>/delete")
def delete_location(item_id):
    row = get_db().execute("SELECT case_id FROM locations WHERE id=?", (item_id,)).fetchone()
    if row is None: abort(404)
    case_id = row["case_id"]
    db = get_db()
    db.execute("DELETE FROM locations WHERE id=?", (item_id,))
    db.commit()
    flash("Local removido.", "success")
    return redirect(url_for("case_detail", case_id=case_id) + "#locations")

@app.post("/cases/<int:case_id>/notes")
def add_note(case_id):
    get_case_or_404(case_id)
    title = request.form.get("title", "").strip()
    body = request.form.get("body", "").strip()
    if not title or not body:
        flash("Informe o título e o conteúdo da anotação.", "error")
    else:
        now = datetime.now().isoformat(timespec="seconds")
        db = get_db()
        db.execute("INSERT INTO notes (case_id, title, body, updated_at) VALUES (?, ?, ?, ?)",
                   (case_id, title, body, now))
        db.execute("UPDATE cases SET updated_at=? WHERE id=?", (now, case_id))
        db.commit()
        flash("Anotação salva.", "success")
    return redirect(url_for("case_detail", case_id=case_id) + "#notes")

@app.post("/notes/<int:item_id>/delete")
def delete_note(item_id):
    row = get_db().execute("SELECT case_id FROM notes WHERE id=?", (item_id,)).fetchone()
    if row is None: abort(404)
    case_id = row["case_id"]
    db = get_db()
    db.execute("DELETE FROM notes WHERE id=?", (item_id,))
    db.commit()
    flash("Anotação removida.", "success")
    return redirect(url_for("case_detail", case_id=case_id) + "#notes")

@app.route("/search")
def search():
    q = request.args.get("q", "").strip()
    results = []
    if q:
        like = f"%{q}%"
        results = get_db().execute("""
          SELECT c.id AS case_id, c.title AS case_title, 'Caso' AS kind, c.summary AS excerpt
          FROM cases c WHERE c.title LIKE ? OR c.summary LIKE ?
          UNION ALL
          SELECT s.case_id, c.title, 'Suspeito', s.name || ' — ' || COALESCE(s.notes, '')
          FROM suspects s JOIN cases c ON c.id=s.case_id WHERE s.name LIKE ? OR s.notes LIKE ? OR s.motive LIKE ?
          UNION ALL
          SELECT cl.case_id, c.title, 'Pista', cl.title || ' — ' || COALESCE(cl.description, '')
          FROM clues cl JOIN cases c ON c.id=cl.case_id WHERE cl.title LIKE ? OR cl.description LIKE ?
          ORDER BY case_title LIMIT 60
        """, (like, like, like, like, like, like, like)).fetchall()
    return render_template("search.html", q=q, results=results)

if __name__ == "__main__":
    app.run(debug=True)
